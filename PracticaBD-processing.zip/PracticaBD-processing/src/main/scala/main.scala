object main {
  def main(args: Array[String]): Unit = {
 Practica.ejercicio1()
 Practica.ejercicio2()
 Practica.ejercicio3()
 Practica.ejercicio4()
 Practica.ejercicio5()

  }
}